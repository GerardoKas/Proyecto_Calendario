Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' La informaci�n general de un ensamblado se controla mediante el siguiente
' conjunto de atributos. Cambie estos atributos para modificar la informaci�n
' asociada con un ensamblado.


' TODO: Revisar los valores de los atributos del ensamblado


<Assembly: AssemblyTitle("Programa Visual Basic que genera calendarios HTML con hojas de Estilo (colores, fuentes, etc)")>
<Assembly: AssemblyDescription("Con Bastantes Errores o Limitaciones")>
<Assembly: AssemblyCompany("GCM_Software")>
<Assembly: AssemblyProduct("GCM_Calendario_2005")>
<Assembly: AssemblyCopyright("Si estas trabajando en algo parecido contactame en gerardocastromtz@hotmail.com")>
<Assembly: AssemblyTrademark("ABRACADABRA y GCM")>
<Assembly: AssemblyCulture("")>

' La informaci�n de versi�n de un ensamblado consta de los cuatro valores siguientes:

'	Versi�n principal
'	Versi�n secundaria
'	N�mero de versi�n de compilaci�n
'	Revisi�n

' Puede especificar todos los valores o establecer como predeterminados los n�meros de versi�n de compilaci�n y de revisi�n
' mediante el asterisco ('*'), tal y como se muestra a continuaci�n:

<Assembly:  AssemblyVersion("1.6.*")>


